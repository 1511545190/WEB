package Apache::Hello;
#
# This file is a sample Perl module to test mod_perl installation.
#
# You should activate it using something like :
#
# <Location /hello>
#    SetHandler perl-script
#    PerlHandler Apache::Hello
# </Location>
#
use strict;
use Apache::Constants qw(:common);
use vars qw($VERSION);

# Content handler
sub handler {
	my $r = shift;
	$r->content_type('text/html');
	$r->send_http_header;
	my $host = $r->get_remote_host;
	$r->print(<<END);
<html>
<head>
	<title>Hello World</title>
</head>
<body>
<h1>Hello $host</h1>
<p>This is a sample Perl module to test mod_perl installation.</p>
<hr>
</body>
</html>
END
	return OK;
}

1;
