package Apache::ProxyFilter;

# Copyright (2003) Sylvain Tissot <stissot@mac.com>
#
# You can download last version of ProxyFilter and
# the documentation at http://proxyfilter.sourceforge.org
#
# This is based on :
#
# - Apache::ReverseProxy by Clinton Wong
# - Apache::ProxyPass by Michael Smith
# - Apache::ProxyPathThru
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 

#  -+-                          -+-
#  -+- IMPORTATIONS DE MODULES  -+-
#  -+-                          -+-

use strict;
use Apache::Constants qw(:common :http :response);
use Apache::Log ();
use Apache::URI ();
use Apache::Request ();
use XML::Parser;
use LWP;
use vars qw($VERSION);

$VERSION = '0.1';

#  -+-                    -+-
#  -+- VARIABLE GLOBALES  -+-
#  -+-                    -+-

# +++ Informations de configuration +++

# Contient la configuration g�n�rale du module
my %config;
# Le default policy (allow|deny) � chaque niveau de l'application web
my %default;
# Indique si l'acc�s � l'index d'un r�pertoire est autoris� (true|false)
my %allowindex;
# Les fichiers autoris�s/interdits de l'application (sans param�tres, sinon ce sont des scripts)
# %file->{allow|deny}->{$path}->{$name}->{inherit|maxlength|minlength|length}
my %file;
# Les URLs autoris�es ou bloqu�es de l'application (exactes ou regexp)
# %url->{allow|deny}->{$path}->{$value}->{inherit|maxlength|minlength|length}
my %url;
# Les scripts autoris�s de l'application. Un script est d�fini comme un
# nom de fichier suivi d'un caract�re '?' suivi des param�tres du script
# sous la forme attribut=valeur s�par�s par un caract�re '&'
my %script;
# La correspondance entre les raccourcis de charsets et leurs �quivalents en expressions r�guli�res
my %charsets;
# R�gles de r��criture d'URL de la requ�te bas�es sur un prefixe
my %prefix_mapping;
# R�gles de r��criture d'URL de la requ�te bas�es sur une chemin d'acc�s exact
my %exact_mapping;
# R�gles de r��criture d'URL de la r�ponse (ent�tes Location et liens hypertextes absolus), �quivalent de ProxyPassReverse
my %reverse_mapping;

# +++ Variables � usage du parseur XML +++

# �lement parent de l'�l�ment courant
my @parentElement;
# Dernier �l�ment ouvrant rencontr� par le parseur
my $lastStart;
# Contenu de la derni�re section #CDATA rencontr�e
my $cdata;
# Dernier �l�ment ouvrant rencontr� par le parser
my $lastStart;
# Dernier �l�ment fermant rencontr� par le parser
my $lastEnd;
# Attribut "name" du dernier �l�ment <script> rencontr� (pour pouvoir y associer les <param> qui suivent)
my $scriptName;
# Dossier courant du parseur
my $pwd;
# R�f�rence sur l'objet Apache::Request pour permettre au parseur d'�mettre des messages de log
my $server = Apache->server;

#  -+-                  -+-
#  -+- CONTENT-HANDLER  -+-
#  -+-                  -+-
sub handler {
	my $r = shift;

	# Ne traite pas les requ�tes de proxy Web
	return DECLINED if $r->proxyreq;

	# Initialisation des variables globales
	%config = undef;
	%default = undef;
	%allowindex = undef;
	%file = undef;
	%url = undef;
	%script = undef;
	%charsets = undef;
	%prefix_mapping = undef;
	%exact_mapping = undef;
	%reverse_mapping = undef;

	# Lecture de la configuration du module
	return SERVER_ERROR unless init(\$r);

	# Filtrage de m�thode HTTP
	my @http_methods = keys %{$config{'http_methods'}};
	my $forbidden = 1;
	for (@http_methods) {
		next unless $r->method =~ /$_/i;
		$forbidden = 0;
		last;
	}
	return FORBIDDEN if $forbidden;

	### Filtrage des ent�tes de la requ�te
	if ($config{'headers_in'}{'default'} eq 'allow') {

		# Default-policy allow --> recherche un header de la requ�te qui satisfasse une r�gle deny ou filter
		my $forbidden = 0;
		$r->headers_in->do(sub {
			my ($header, $value) = @_;
			debug ("Request header : $header = $value", \$r->server->log);
			if (exists $config{'headers_in'}{'deny'}{lc $header}) {
				$r->headers_in->unset($header);
				info ("header_in $header forbidden by rule", \$r->server->log);
				$forbidden = 1;
				return 0;
			}
			if (exists $config{'headers_in'}{'filter'}{lc $header}) {
				$r->headers_in->unset($header);
				debug ("header_in $header has been filtered by rule", \$r->server->log);
			}
			1;
		});
		return FORBIDDEN if $forbidden;

	} elsif ($config{'headers_in'}{'default'} eq 'deny') {

		# Default-policy deny --> pour chaque header de la requ�te, recherche d'une r�gle allow ou filter correspondante
		my $forbidden = 0;
		$r->headers_in->do(sub {
			my ($header, $value) = @_;
			debug ("Request header : $header = $value", \$r->server->log);
			if (exists $config{'headers_in'}{'filter'}{lc $header}) {
				debug ("header_in $header has been filtered by rule", \$r->server->log);
				$r->headers_in->unset($header);
			} elsif (exists $config{'headers_in'}{'allow'}{lc $header}) {

				my %headerRule = %{ $config{'headers_in'}{'allow'}{lc $header} };

				if (! matchHeader($value, %headerRule)) {
					$r->headers_in->unset($header);
					info ("header_in $header forbidden by rule : no matching allow rule", \$r->server->log);
					$forbidden = 1;
					return 0;
				}

			} else {
				# Aucune r�gle allow correspondant � ce header --> requ�te interdite
				$r->headers_in->unset($header);
				info ("header_in $header forbidden by default rule : no matching allow rule", \$r->server->log);
				$forbidden = 1;
				return 0;
			}
			1;
		});

		return FORBIDDEN if $forbidden;

	} elsif ($config{'headers_in'}{'default'} eq 'filter') {

		# Default-policy filter --> pour chaque header de la requ�te, recherche une r�gle deny, puis allow correspondante
		my $forbidden = 0;
		$r->headers_in->do(sub {
			my ($header, $value) = @_;
			debug ("Request header : $header = $value", \$r->server->log);

			if (exists $config{'headers_in'}{'deny'}{lc $header}) {
				info ("header_in $header forbidden by rule", \$r->server->log);
				$r->headers_in->unset($header);
				$forbidden = 1;
				return 0;
			} elsif (exists $config{'headers_in'}{'allow'}{lc $header}) {
				my %headerRule = %{ $config{'headers_in'}{'allow'}{lc $header} };
				if (!matchHeader($value, %headerRule)) {
					$r->headers_in->unset($header);
					debug ("header_in $header has been filtered : no matching allow rule", \$r->server->log);
				}
				# Une r�gle allow --> ent�te valide
			} else {
				# Aucune r�gle allow ou deny --> ent�te filtr�e
				$r->headers_in->unset($header);
				debug ("header_in $header has been filtered by default rule : no matching allow rule", \$r->server->log);
			}
			1;
		});
		
		return FORBIDDEN if $forbidden;

	} else {
		error ("Bad default policy for \"headers_in\", must be deny, allow or filter", \$r->server->log);
		return SERVER_ERROR;
	}

	### Fin de filtrage des ent�tes de la requ�te

	### D�but de r��criture d'URL de la requ�te
	
	my $rewritten = 0;
	my $rewrittenUrl = $r->uri;

	# Essaie une translation d'URL exacte
	while (my ($srcUrl, $tgtUrl) = each %exact_mapping) {
		next if ($srcUrl eq '' || $tgtUrl eq '');
		if ($rewrittenUrl =~ s|^$srcUrl$|$tgtUrl|i) {
			$rewritten = 1;
			last;
		}
	}

	# Essaie une translation d'URL bas�e sur le pr�fixe
	if (!$rewritten) {
		while (my ($srcUrl, $tgtUrl) = each %prefix_mapping) {
			next if ($srcUrl eq '' || $tgtUrl eq '');
			if ($rewrittenUrl =~ s/^$srcUrl/$tgtUrl/i) {
				$rewritten = 1;
				last;
			}
		}
	}

	if (!$rewritten) {
		warning ("request to $r->uri was declined, no matching URL mapping rule", \$r->server->log);
		return DECLINED;
	}

	### Fin de r��criture d'URL de la requ�te

	info ("source URI : ".$r->uri, \$r->server->log);
	info ("target URL : $rewrittenUrl", \$r->server->log);
	# debug ("\n*** Target URI ***\n".$r->method.' '.$r->uri.' '.$r->protocol, \$r->server->log);

	my $nbGetArgs = 0;
	my $nbPostArgs = 0;

	# Lecture des param�tres GET de la requ�te (technique supportant les champs multivalu�s)
	my $get_params = Apache::Table->new($r);
	my @args = $r->args;
	while (my ($name, $value) = splice @args,0,2) {
		$get_params->add($name, $value);
	}
	# Extrait les �ventuels param�tres GET de l'URL r��crite
	if ($rewrittenUrl =~ s|\?([^\?/]+)$||) {
		my @pairs = split(/&/, $1);
		for my $pair (@pairs) {
			split(/=/, $pair);
			$get_params->add(@_[0], @_[1]);
		}
	}

	# Lecture des param�tres POST de la requ�te (au format x-www-form-urlencoded uniquement)
	my $post_params = Apache::Table->new($r);
	my $ct = $r->header_in('Content-type');
	if (lc $ct eq 'application/x-www-form-urlencoded') {
		my @args = $r->content();
		while (my ($name, $value) = splice @args,0,2) {
			$post_params->add($name, $value);
		}
	}
	
	# Affiche dans le log et �num�re les param�tres GET et POST
	my $info = '';
	$get_params->do(sub{
		my ($key, $value) = @_;
		$info .= "\n  $key => $value";
		$nbGetArgs++;
		1;
	});
	if ($nbGetArgs) {
		debug('-> parametres GET:' . $info, \$r->server->log);
	}
	$info = '';
	$post_params->do(sub{
		my ($key, $value) = @_;
		$info .= "\n  $key => $value";
		$nbPostArgs++;
		1;
	});
	if ($nbPostArgs) {
		debug('-> parametres POST:\n' . $info, \$r->server->log);
	}

	my $targetServer;
	my $pwd;
	my $fileName;
	my $rewrittenUri = $rewrittenUrl;
	if ($rewrittenUri =~ s|^https?://([^/]+)||i) {
		$targetServer = $1; # Extrait le nom du serveur cible de l'URL r��crite
		$pwd = $rewrittenUri;
		$pwd =~ s|([^/]*)$||;
		$fileName = $1;	# Extrait le nom du fichier de l'URL r��crite
	} else {
		error ("bad URL format : $rewrittenUrl", \$r->server->log);
		return SERVER_ERROR;		
	}

	# <DEBUG>
	debug ("targetServer: $targetServer\npwd=$pwd\nfileName=$fileName", \$r->server->log);
	# </DEBUG>

	### Evaluation des r�gles <url>

	my $verdict;
	my $forbidden_msg;
	my $uriWithParams = &addParamString($rewrittenUri, $get_params);

	$verdict = &urlAllowed($uriWithParams);

	if ($verdict == -1) {
		$forbidden_msg = "access denied by URL rule to $uriWithParams";
		warning ("Request denied : $forbidden_msg", \$r->server->log);
		return FORBIDDEN;
	} elsif ($verdict == 1) {
		debug ("Request approved by URL rule to $uriWithParams", \$r->server->log);
	}
	
	### Evaluation des autres r�gles en cas de neutralit� des r�gles <url>

	# La requ�te doit concerner un r�pertoire valide d�fini dans le fichier webapp
	if (! exists $default{$pwd}) {
		$forbidden_msg = "invalid directory";
		$verdict = -1;
	}

	if ($verdict == 0) {
	
		if ($nbGetArgs || $nbPostArgs) {

			### C'est une requ�te de type script (avec param�tres)

			my %scriptRequest = ($fileName => {
								'get' => $get_params,
								'post' => $post_params
								});

			if (&scriptAllowed(\%scriptRequest, $pwd)) {
				if (&getDefault($pwd) eq 'allow' && !&fileAllowed($fileName, $pwd)) {
					$forbidden_msg = "access denied by FILE rule to $rewrittenUri";
					$verdict = -1;
				} else {
					debug ("Request approved by SCRIPT rule to $uriWithParams", \$r->server->log);
					$verdict = 1;
				}
			} else {
				$forbidden_msg = "access denied by SCRIPT rule to $uriWithParams";
				$verdict = -1;
			}

		} else {

			### C'est une requ�te de type file (sans param�tre)

			if (&fileAllowed($fileName, $pwd)) {
				debug ("Request approved by FILE rule to $uriWithParams", \$r->server->log);
				$verdict = 1;
			} else {
				$forbidden_msg = "access denied by FILE rule to $rewrittenUrl";
				$verdict = -1;
			}

		}

	}

	if ($verdict != 1) {
		warning ("Request denied : $forbidden_msg", \$r->server->log);
		return FORBIDDEN;
	}


	### Cr�ation de la requ�te interne

	# Ajoute les �ventuels param�tres GET � la suite de l'URL
	$rewrittenUrl = &addParamString ($rewrittenUrl, $get_params);

	if ($nbGetArgs || $nbPostArgs) {
		info ("target URL with params : $rewrittenUrl", \$r->server->log);
	}

	# Cr�e la requ�te devant �tre transmise au client HTTP
	my $request = new HTTP::Request($r->method, $rewrittenUrl);

	# Ajout des param�tres POST � la requ�te
	my $entity_body = '';
	if ($nbPostArgs) {
		# Compose une cha�ne application/x-www-form-urlencoded avec les param�tres POST
		my $firstTime = 1;
		$post_params->do(sub {
			my ($key, $value) = @_;
			if ($firstTime) {
				$entity_body .= $key.'='.$value;
				$firstTime = 0;
			} else {
				$entity_body .= '&'.$key.'='.$value;
			}
			1;
		});
	} else {
		# Si les param�tres POST ne sont pas au format application/x-www-form-urlencoded, tente
		# de copier les donn�es POST brutes de la requ�te (envoi de fichier par multipart/form-data)
		$r->read($entity_body, $r->header_in('Content-length'));
	}
	if (length $entity_body) {
		if (!$nbPostArgs) {warning ("$ct encoding not supported for POST data --> copy without parsing", \$r->server->log);}
		$request->content($entity_body);
	}

	# Copie les ent�tes de la requ�te du client (sauf Host qui est extrait de l'URL cible absolue)
	$r->headers_in->do(sub {
		my ($headerName, $headerValue) = @_;
		if (lc $headerName ne 'host') {
			$request->header($headerName => $headerValue);
		}
		1;
	});

	# Cr�e une instance du client HTTP devant se charger de la requ�te au serveur cible
	my $ua = new LWP::UserAgent();

	# Configure le client HTTP
	if (defined $r->header_in('user-agent') && length $r->header_in('user-agent')) {
		$ua->agent($r->header_in('user-agent'));
	}
	if (defined $r->header_in('content-type') && length $r->header_in('content-type')) {
		$request->header('content-type', $r->header_in('content-type'));
	}


=start
	my $entity_body = $r->content();
	if (defined $entity_body && length $entity_body) {
		$request->content($entity_body);
	} else {
		my $buffer = '';
		$r->read($buffer, $r->header_in('Content-length'));
		if (length $buffer) {
			$request->content($buffer);
		}
	}
=cut

	my $getCalled = 0;
	my $documentContent = '';
	my $forbidden = 0;
	my $serverError = 0;
	my $response = $ua->request($request,
	sub { ### D�but du handler de la r�ponse

		my ($data, $response, $protocol) = @_;
		debug ("response routine call $getCalled", $r->server->log);
		if (!$getCalled) { # First handler call -> copy response headers

			my $headerStatus = headersOutFilter(\$response, \$r);
			if ($headerStatus == 1) {
				$r->send_http_header;
				# debug ("Envoi des entetes dans le response handler", \$r->server->log);
			} elsif ($headerStatus == 0) {
				$forbidden = 1;
				die();
			} elsif ($headerStatus == -1) {
				$serverError = 1;
				die();
			}
		}
		$documentContent .= $data;
		$getCalled++;
		1;
	}); ### Fin du handler de la r�ponse

	# Traite le cas particulier des requ�tes HEAD (la r�ponse ne comporte que les ent�tes)
	if ($r->header_only && !$getCalled) {
		info ("Requ�te HEAD", \$r->server->log);
		headersOutFilter(\$response, \$r);
		if (headersOutFilter(\$response, \$r)) {
			$r->send_http_header;
			# debug ("Envoi des entetes dans le HEAD handler", \$r->server->log);
			return OK;
		} elsif ($_ == 0) {
			$forbidden = 1;
			return 0;			
		} elsif ($_ == -1) {
			$serverError = 1;
			return 0;			
		}

		$r->send_http_header();
		return OK;
	}

	# Traite les erreurs ayant pu survenir durant le parcours des ent�tes de la r�ponse
	return FORBIDDEN if $forbidden;
	return SERVER_ERROR if $serverError;

	# Si le response handler n'a pas �t� appel� au moins une fois, cela signifie
	# que la requ�te a �chou� dans ce cas on g�re ce cas ici en propageant le message d'erreur
	if (!$getCalled) {
		warning ("The response handler was not called", \$r->server->log);
		my $headerStatus = headersOutFilter(\$response, \$r);
		if ($headerStatus == 1) {
			$r->send_http_header;
			$r->print($response->content());
			return OK;
		} elsif ($headerStatus == 0) {
			return FORBIDDEN;
		} elsif ($headerStatus == -1) {
			return SERVER_ERROR;
		}
	}

	### Filtrage de contenu du document retourn� et r��criture des liens hypertextes relatifs au serveur cible

	if ($r->content_type eq 'text/html') {
		debug ("Le document ".$r->parsed_uri->path." est de type HTML", \$r->server->log);
		$r->print($documentContent);
	} else {
		debug ("Le document ".$r->parsed_uri->path." est de type ".$r->content_type, \$r->server->log);
		$r->print($documentContent);
	}

	return OK;

	# $r->content_type('text/plain');
	# $r->send_http_header;
	# showConfig();
	# return OK;

	1;
	
} # handler

#  -+-                           -+-
#  -+- INITIALISATION DU MODULE  -+-
#  -+-                           -+-
sub init {

	my $r = ${ shift @_ };

	# Obtient le nom du fichier de configuration
	$config{'configfile'} = $r->server->dir_config('ProxyFilterConfig');
	if (!defined $config{'configfile'}) {
		error('ProxyFilterConfig directive not defined', \$r->server->log);
		return 0;
	} elsif (! -f $config{'configfile'}) {
		error("$config{'configfile'} is not a valid file", \$r->server->log);
		return 0;
	}

	# Cr�e une instance du parseur XML et lui associe les handlers pour le fichier de configuration
	my $parser = new XML::Parser;
	$parser->setHandlers(Start => \&startHandler_config,
						Char => \&charHandler_config,
						End => \&endHandler_config);

	# Parse le fichier de configuration
	$parser->parsefile($config{'configfile'});

	if (!defined $config{'webappfile'}) {
		error('<webappfile> directive is required in the config file', \$r->server->log);
		return 0;
	} elsif (! -f $config{'webappfile'}) {
		error("$config{'webappfile'} is not a valid file", \$r->server->log);
		return 0;
	}

	# Modifie les handlers pour la lecture du fichier webapp
	$parser->setHandlers(Start => \&startHandler_webapp,
						End => \&endHandler_webapp);

	# Parse le fichier webapp
	$parser->parsefile($config{'webappfile'});

	# Lecture du fichier charsets
	if (!readCharsets ($config{'charsetsfile'})) {
		error("unable to read the file \"$config{'charsetsfile'}\"", \$r->server->log);
		return 0;
	}

	# Lecture du fichier mappings
	if (!readMappings ($config{'mappingsfile'})) {
		error("unable to read the file \"$config{'mappingsfile'}\"", \$r->server->log);
		return 0;
	}

	return 1;

}

#  -+-                                   -+-
#  -+- PARSEUR XML DU FICHIER DE CONFIG  -+-
#  -+-                                   -+-

# Appel� au d�but d'un �l�ment du fichier config
sub startHandler_config {
	shift @_;
	my $element = lc shift @_;
	my $i = 0;
	my %params;
	while ($i < $#_) {
		my $key = lc @_[$i++];
		my $value = @_[$i++];
		$params{$key} = $value;
	}
	$cdata = undef;

	if ($element eq 'config') {
		push @parentElement, $element;
	} elsif ($element eq 'charsetsfile') {
		error ('<charsetsfile> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
	} elsif ($element eq 'mappingsfile') {
		error ('<mappingsfile> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
	} elsif ($element eq 'webappfile') {
		error ('<webappfile> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
	} elsif ($element eq 'logfile') {
		error ('<logfile> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
	} elsif ($element eq 'loglevel') {
		error ('<loglevel> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
	} elsif ($element eq 'http_methods') {
		error ('<http_methods> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
	} elsif ($element eq 'headers_in') {
		error ('<headers_in> can only appear in <config> element.', \$server->log) unless $parentElement[$#parentElement] eq 'config';
		error ('<headers_in> must have a "default" attribute.', \$server->log) unless defined $params{'default'};
		$config{'headers_in'}{'default'} = $params{'default'};
		push @parentElement, $element;
	} elsif ($element eq 'headers_out') {
		error ("<headers_out> can only appear in <config> element.", \$server->log) unless $parentElement[$#parentElement] eq 'config';
		error ('<headers_out> must have a "default" attribute.', \$server->log) unless defined $params{'default'};
		$config{'headers_out'}{'default'} = $params{'default'};
		push @parentElement, $element;
	} elsif ($element eq 'allow') {
		error ('<allow> can only appear in <headers_in> or <headers_out> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(headers_in|headers_out)/;
		push @parentElement, $element;
	} elsif ($element eq 'deny') {
		error ('<deny> can only appear in <headers_in> or <headers_out> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(headers_in|headers_out)/;
		push @parentElement, $element;
	} elsif ($element eq 'filter') {
		error ('<filter> can only appear in <headers_in> or <headers_out> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(headers_in|headers_out)/;
		push @parentElement, $element;
	} elsif ($element eq 'header') {
		error ('<header> can only appear in <allow>, <deny> or <filter> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(allow|deny|filter)/;
		error ('<header> must have a "name" attribute.', \$server->log) unless defined $params{'name'};

		# Toutes les cl�s en lettres minuscules pour faciliter la recherche
		my $headername = lc $params{'name'};
		my $headertype = $parentElement[$#parentElement-1];

		if (defined $params{'value'}) {
			$config{$headertype}{$parentElement[$#parentElement]}{$headername}{'value'} = $params{'value'};
		} else {
			$config{$headertype}{$parentElement[$#parentElement]}{$headername}{'value'} = '~.*';
		}
		if (defined $params{'length'}) {
			$config{$headertype}{$parentElement[$#parentElement]}{$headername}{'length'} = $params{'length'};
		} else {
			if (defined $params{'minlength'}) {
				$config{$headertype}{$parentElement[$#parentElement]}{$headername}{'minlength'} = $params{'minlength'};
			}
			if (defined $params{'maxlength'}) {
				$config{$headertype}{$parentElement[$#parentElement]}{$headername}{'maxlength'} = $params{'maxlength'};
			}
		}
	}

	$lastStart = $element;

}

# Appel� lorsque des donn�es PCDATA sont rencontr�es dans le fichier config
sub charHandler_config {
	shift @_;
	$cdata .= shift @_;
}

# Appel� � la fin d'un �l�ment du fichier config
sub endHandler_config {
	shift @_;
	my $element = shift @_;
	$cdata =~ s/^\s*([-_a-zA-Z0-9]+)\s*$/$1/;
	if ($element eq 'charsetsfile') {
		$config{'charsetsfile'} = $cdata;
	} elsif ($element eq 'mappingsfile') {
		$config{'mappingsfile'} = $cdata;
	} elsif ($element eq 'logfile') {
		$config{'logfile'} = $cdata;
	} elsif ($element eq 'loglevel') {
		if (lc $cdata =~ m/^(warning|debug|error|info)$/) {
			$config{'loglevel'} = $cdata;
		} else {
			error ('<loglevel> attribute must be one of warning|debug|error|info.', \$server->log);
		}
	} elsif ($element eq 'http_methods') {
		my @methods = split (',', $cdata);
		for (@methods) {
			$config{'http_methods'}{$_} = ' ';
		}
	} elsif ($element eq 'webappfile') {
		$config{'webappfile'} = $cdata;
	} elsif ($element eq 'allow') {
		pop @parentElement;
	} elsif ($element eq 'deny') {
		pop @parentElement;
	} elsif ($element eq 'filter') {
		pop @parentElement;
	} elsif ($element eq 'headers_out') {
		pop @parentElement;
	} elsif ($element eq 'headers_in') {
		pop @parentElement;
	}
}

#  -+-                                -+-
#  -+- PARSEUR XML DU FICHIER WEBAPP  -+-
#  -+-                                -+-

# Appel� au d�but d'un �l�ment du fichier webapp
sub startHandler_webapp {
	shift @_;
	my $element = lc shift @_;
	my $i = 0;
	my %params = undef;
	while ($i < $#_) {
		my $key = lc @_[$i++];
		my $value = @_[$i++];
		$params{$key} = $value;
	}

	if ($element eq 'webapp') {

		error ('<webapp> must have a "default" attribute', \$server->log) unless defined $params{'default'};
		$default{'/'} = $params{'default'};
		error ('<webapp> must have a "allowindex" attribute', \$server->log) unless defined $params{'allowindex'};
		$default{'/'} = $params{'default'};
		$pwd = '/';
		$allowindex{$pwd} = $params{'allowindex'} if defined $params{'allowindex'};
		push @parentElement, $element;

	} elsif ($element eq 'directory') {

		error ('<directory> must have a "name" attribute.', \$server->log) unless defined $params{'name'};
		my $directoryName = $params{'name'};
		error ('"name" attribute of <directory> cannot contains characters like "/".', \$server->log) if ($directoryName =~ /\//);
		$pwd .= "$directoryName/";
		if (defined $params{'default'}) {
			$default{$pwd} = $params{'default'};
		} else {
			$default{$pwd} = 'inherit';
		}
		$allowindex{$pwd} = $params{'allowindex'} if defined $params{'allowindex'};
		push @parentElement, $element;

	} elsif ($element eq 'deny') {

		error ('<deny> can only appear in <webapp> or <directory> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(directory|webapp)/;
		error ('bad place for an <deny> element, look at the DTD.', \$server->log) unless $lastEnd =~ /(allow|directory|webapp)/;
		push @parentElement, $element;

	} elsif ($element eq 'allow') {

		error ('<allow> can only appear in <webapp> or <directory> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(directory|webapp)/;
		error ('bad place for an <allow> element, look at the DTD.', \$server->log) unless $lastStart =~ /(directory|webapp)/;
		push @parentElement, $element;

	} elsif ($element eq 'file') {

		error ('<file> can only appear in <allow> or <deny> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(allow|deny)/;
		error ('bad place for an <file> element, look at the DTD.', \$server->log) unless ($lastStart =~ /(allow|deny)/ || $lastEnd eq 'file');
		error ('<file> must have a "name" attribute.', \$server->log) unless defined $params{'name'};
		my $fileName = $params{'name'};
		error ('"name" attribute of <file> cannot contains characters like "/".', \$server->log) if ($fileName =~ /\//);
		if (defined $file{$parentElement[$#parentElement]}{$pwd}{$fileName}) {
			warning ("file \"$pwd$fileName\" already exists, I only consider the first occurence.", \$server->log);
		} else {
			my $inherit = 'false'; # Valeur par d�faut
			$inherit = $params{'inherit'} if defined $params{'inherit'};
			$file{$parentElement[$#parentElement]}{$pwd}{$fileName}{'inherit'} = $inherit;
			if (defined $params{'length'}) {
				$file{$parentElement[$#parentElement]}{$pwd}{$fileName}{'length'} = $params{'length'};
			} else {
				$file{$parentElement[$#parentElement]}{$pwd}{$fileName}{'minlength'} = $params{'minlength'} || undef;
				$file{$parentElement[$#parentElement]}{$pwd}{$fileName}{'maxlength'} = $params{'maxlength'} || undef;
			}

		}

	} elsif ($element eq 'url') {	

		error ('<url> can only appear in <allow> or <deny> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /(allow|deny)/;
		error ('bad place for an <url> element, look at the DTD.', \$server->log) unless ($lastStart =~ /(allow|deny)/ || $lastEnd =~ /(file|url)/);
		error ('<url> must have a "value" attribute.', \$server->log) unless defined $params{'value'};
		error ('<url> can only appear in an <allow> or <deny> element which at <webapp> first level', \$server->log) unless $parentElement[$#parentElement-1] eq 'webapp';
		my $urlValue = $params{'value'};
		if (defined $params{'length'}) {
			$url{$parentElement[$#parentElement]}{$urlValue}{'length'} = $params{'length'};
		} else {
			$url{$parentElement[$#parentElement]}{$urlValue}{'minlength'} = $params{'minlength'} || undef;
			$url{$parentElement[$#parentElement]}{$urlValue}{'maxlength'} = $params{'maxlength'} || undef;
		}

	} elsif ($element eq 'script') {

		error ('<script> can only appear in <allow> or <deny> elements.', \$server->log) unless $parentElement[$#parentElement] =~ /allow|deny/;
		error ('<script> must have a "name" attribute.', \$server->log) unless defined $params{'name'};
		$scriptName = $params{'name'};
		error ('"name" attribute of <script> cannot contains characters like "/".', \$server->log) if ($scriptName =~ /\//);
		my $inherit = 'false'; # Valeur par d�faut
		$inherit = $params{'inherit'} if defined $params{'inherit'};
		$script{$parentElement[$#parentElement]}{$pwd}{$scriptName}{'inherit'} = $inherit;
		if (defined $params{'length'}) {
			$script{$parentElement[$#parentElement]}{$pwd}{$scriptName}{'length'} = $params{'length'};
		} else {
			$script{$parentElement[$#parentElement]}{$pwd}{$scriptName}{'minlength'} = $params{'minlength'} || undef;
			$script{$parentElement[$#parentElement]}{$pwd}{$scriptName}{'maxlength'} = $params{'maxlength'} || undef;
		}
		push @parentElement, $element;

	} elsif ($element eq 'param') {
		error ('<param> can only appear in <script> elements.', \$server->log) unless ($parentElement[$#parentElement] eq 'script' && defined $scriptName);
		error ('bad place for an <param> element, lood at the DTD.', \$server->log) unless ($lastEnd eq 'param' || $lastStart eq 'script');
		error ('"name", "value" and "method" attributes are mandatory in <param> element', \$server->log) unless (defined $params{'name'} && defined $params{'value'} && defined $params{'method'});
		my $paramName = $params{'name'};
		my $paramValue = $params{'value'};
		my $paramMethod = $params{'method'};
		$script{$parentElement[$#parentElement-1]}{$pwd}{$scriptName}{'params'}{$paramName}{'value'} = $paramValue;
		$script{$parentElement[$#parentElement-1]}{$pwd}{$scriptName}{'params'}{$paramName}{'method'} = $paramMethod;
		my $optional = 'true'; # Valeur par d�faut
		$optional = $params{'optional'} if defined $params{'optional'};
		$script{$parentElement[$#parentElement-1]}{$pwd}{$scriptName}{'params'}{$paramName}{'optional'} = $optional;
		if (defined $params{'length'}) {
			$script{$parentElement[$#parentElement-1]}{$pwd}{$scriptName}{'params'}{$paramName}{'length'} = $params{'length'};
		} else {
			$script{$parentElement[$#parentElement-1]}{$pwd}{$scriptName}{'params'}{$paramName}{'minlength'} = $params{'minlength'} || undef;
			$script{$parentElement[$#parentElement-1]}{$pwd}{$scriptName}{'params'}{$paramName}{'maxlength'} = $params{'maxlength'} || undef;
		}
	}

	$lastStart = $element;

}

# Appel� � la fin d'un �l�ment du fichier webapp
sub endHandler_webapp {
	shift @_;
	my $element = lc shift @_;

	if ($element eq 'webapp') {
	
	} elsif ($element eq 'directory') {
	
		$pwd =~ s|^(.*/)([^/]+)/$|$1|;
		pop @parentElement;
	
	} elsif ($element eq 'deny') {

		pop @parentElement;

	} elsif ($element eq 'allow') {

		pop @parentElement;

	} elsif ($element eq 'file') {

	} elsif ($element eq 'url') {	

	} elsif ($element eq 'script') {

		$scriptName = undef;
		pop @parentElement;

	} elsif ($element eq 'param') {

	}

	$lastEnd = $element;
}

#  -+-                                                   -+-
#  -+- LECTURE DES FICHIERS DE CONFIGURATION (hors-XML)  -+-
#  -+-                                                   -+-

# Lit le contenu du fichier charsets
sub readCharsets {
	my $charsetsFile = @_[0];
	return 0 unless open CHARSET, $charsetsFile;
	while (<CHARSET>) {
		chomp;
		if (/([a-zA-Z0-9]+)\t+(.*)/) {
			$charsets{$1} = $2;
		}
	}
	close CHARSET;
	return 1;
}

# Lit le contenu du fichier mappings
sub readMappings {
	my $mappingsFile = @_[0];
	return 0 unless open MAPPING, $mappingsFile;

	%prefix_mapping = ( );
	%exact_mapping = ( );
	%reverse_mapping = ( );

	while (<MAPPING>) {
		chomp;
		if (/^\w*#/) {
			next; # Ignore les lignes de commentaires
		} elsif (m|^\s*([^\s]+)\s+([^\s]+)\s+([^\s]+)|) {
			my $srcUrl = $1;
			my $tgtUrl = $2;
			my $ruleType = $3;

			if (!defined $ruleType || $ruleType =~ m|forward|i) {
				$prefix_mapping{$srcUrl} = $tgtUrl;
			} elsif ($ruleType =~ m|exact|i) {
				$exact_mapping{$srcUrl} = $tgtUrl;
			} elsif ($ruleType =~ m|reverse|i) {
				$reverse_mapping{$srcUrl} = $tgtUrl;
			}
		}
	}
	close CHARSET;
	return 1;
}

#  -+-                                    -+-
#  -+- COMPARAISON DE PARAMETRES / REGLES -+-
#  -+-                                    -+-

# Retourne le default-policy � un certain niveau de l'application
#
# Param�tres :
#
#  1) $pwd : working directory path
#
sub getDefault {
	my $pwd = shift @_;
	while (!exists $default{$pwd} || $default{$pwd} eq 'inherit') {
		$pwd =~ s|(.*/)[^/]+/|$1|;
	}
	return $default{$pwd};
}

# Retourne si l'index de r�pertoire est autoris� � un niveau de l'application
#
# Param�tres :
#
#  1) $pwd : working directory path
#
sub getAllowIndex {
	my $pwd = shift @_;
	while (!defined $allowindex{$pwd}) {
		$pwd =~ s|(.*/)[^/]+/|$1|;
	}
	return $allowindex{$pwd};
}

# Retourne les fichiers autoris�s/interdits � un niveau de l'application
#
# Param�tres :
#
#  1) $pwd : working directory path
#  2) $policy : deny | allow
#
# Valeur retourn�e : un hash contenant un ensemble de fileRules
#
sub getFiles {
	my ($pwd, $policy) = @_;
	my %resultFiles;
	# Recherche les fichiers au niveau courant de la hi�rarchie
	if (exists $file{$policy}{$pwd}) {
		%resultFiles = %{ $file{$policy}{$pwd} };
	}
	# Recherche les fichiers aux niveaux sup�rieurs de la hi�rarchie (jusqu'� la racine), avec inherit=true
	while ($pwd ne '/') {
		$pwd =~ s|(.*/)[^/]+/|$1|;
		if (exists $file{$policy}{$pwd}) {
			my %localFiles = %{ $file{$policy}{$pwd} };
			foreach my $aFile (keys %localFiles) {
				if ($file{$policy}{$pwd}{$aFile}{'inherit'} eq 'true' && !defined $resultFiles{$aFile}) {
					# Copie la r�f�rence du fichier dans le hash du r�sultat, si inherit=true
					$resultFiles{$aFile} = $file{$policy}{$pwd}{$aFile};
				}
			}
		}
	}
	return %resultFiles;
}

# Retourne les URLs autoris�es/interdites
#
# Param�tres :
#
#  1) $policy : deny | allow
#
sub getUrls {
	my $policy = shift @_;
	my %resultUrls;
	# Recherche les urls au niveau courant de la hi�rarchie
	if (exists $url{$policy}) {
		%resultUrls = %{ $url{$policy} };
	}
	return %resultUrls;
}

# Retourne les scripts autoris�s/interdits � un niveau de l'application
#
# Param�tres :
#
#  1) $pwd : working directory path
#  2) $policy : deny | allow
#
sub getScripts {
	my ($pwd, $policy) = @_;
	my %resultScripts;
	# Recherche les scripts au niveau courant de la hi�rarchie
	if (exists $script{$policy}{$pwd}) {
		%resultScripts = %{ $script{$policy}{$pwd} };
	}
	# Recherche les scripts aux niveaux sup�rieurs de la hi�rarchie (jusqu'� la racine), avec inherit=true
	while ($pwd ne '/') {
		$pwd =~ s|(.*/)[^/]+/|$1|;
		if (exists $script{$policy}{$pwd}) {
			my %localScripts = %{ $script{$policy}{$pwd} };
			foreach my $aScript (keys %localScripts) {
				if ($script{$policy}{$pwd}{$aScript}{'inherit'} eq 'true' && !defined $resultScripts{$aScript}) {
					# Copie la r�f�rence du script dans le hash du r�sultat, si inherit=true
					$resultScripts{$aScript} = $script{$policy}{$pwd}{$aScript};
				}
			}
		}
	}
	return %resultScripts;
}

# Teste si la valeur d'une ent�te HTTP satisfait une r�gle <header>
#
# Param�tres :
#
#  1) $headerValue : valeur de l'ent�te � �valuer (la correspondance du nom est v�rifi�e en amont)
#  2) %headerRule : r�gle <header> avec laquelle l'ent�te doit �tre �valu�e
#
sub matchHeader {
	my $headerValue = shift @_;
	my %headerRule = @_;
	my $headerRuleValue = $headerRule{'value'};

	# Teste si la r�gle emploie la syntaxe regexp
	if (substr($headerRuleValue, 0, 1) eq '~') {
	
		### Expression r�guli�re
		
		# Teste la longueur de la valeur du param�tre
		if (defined $headerRule{'length'}) {
			return 0 unless length $headerValue == $headerRule{'length'};
		} else {
			if (defined $headerRule{'maxlength'}) {
				return 0 unless length $headerValue <= $headerRule{'maxlength'};
			}
			if (defined $headerRule{'minlength'}) {
				return 0 unless length $headerValue >= $headerRule{'minlength'};
			}
		}

		substr($headerRuleValue, 0, 1, ''); # Efface le caract�re '~' au d�but de l'expression

		# Traitement des r�f�rences de charsets
		while ($headerRuleValue =~ /.*%([-_a-zA-Z0-9]+)%.*/) {
			my $charset = $1;
			$headerRuleValue =~ s/(.*)(%[-_a-zA-Z0-9]+%)(.*)/$1$charsets{$charset}$3/;
		}

		# Teste si la valeur d'ent�te de la requ�te/r�ponse correspond � celle de la r�gle
		return 0 unless $headerValue =~ /$headerRuleValue/i; # Insensible � la casse !

		return 1;

	} elsif ($headerValue =~ /(.*)%([^%]+)%(.*)/) {

		### Expression simple utilisant un charset

		# Teste la longueur de la valeur du param�tre
		if (defined $headerRule{'length'}) {
			return 0 unless length $headerValue == $headerRule{'length'};
		} else {
			if (defined $headerRule{'maxlength'}) {
				return 0 unless length $headerValue <= $headerRule{'maxlength'};
			}
			if (defined $headerRule{'minlength'}) {
				return 0 unless length $headerValue >= $headerRule{'minlength'};
			}
		}

		# D�coupe du headerRuleValue en 3 slices (exact, regexp, exact)
		my @ruleSlices = (lc $1, $2, lc $3);

		# Remplacement du charset par sa valeur en expression r�guli�re
		if (exists $charsets{$ruleSlices[1]}) {
			$ruleSlices[1] = $charsets{$ruleSlices[1]};
		}

		# D�coupe la valeur de l'ent�te en 3 slices de longueur correspondante aux slices du headerRuleValue
		my @headerValueSlices;
		$headerValueSlices[0] = lc substr($headerValue, 0, length $ruleSlices[0], '');
		$headerValueSlices[2] = lc substr($headerValue, (length $headerValue)-(length $ruleSlices[2]), length $ruleSlices[2], '');
		$headerValueSlices[1] = $headerValue;

		# Application des r�gles pour les 3 slices (insensible � la casse !)
		return 0 unless $headerValueSlices[0] eq $ruleSlices[0];
		return 0 unless $headerValueSlices[1] =~ /^$ruleSlices[1]$/i;
		return 0 unless $headerValueSlices[2] eq $ruleSlices[2];

		return 1;

	} else {
	
		### Expression simple sans charset ("exact match")

		return 0 unless $headerValue =~ /$headerRuleValue/i;
		return 1;
	
	}
}

# Teste si un nom de fichier (1er param�tre) satisfait une r�gle <file> (2�me param�tre)
#
# Param�tres :
#
#  1) $fileName : nom du fichier (derni�re partie de l'URL apr�s le "/" et avant l'�ventuel "?")
#  2) %fileRule : r�gle <file> avec laquelle le nom de fichier doit �tre �valu�
#
sub matchFile {

	my ($fileName, %fr) = @_;
	my $fileRule = (keys %fr)[0];
	my %fileRuleAtt = %{ $fr{$fileRule} };

	# Teste si la r�gle emploie la syntaxe regexp
	if (substr($fileRule, 0, 1) eq '~') {

		### Expression r�guli�re ###

		# Teste la longueur totale du nom de fichier
		if (defined $fileRuleAtt{'length'}) {
			return 0 unless length $fileName == $fileRuleAtt{'length'};
		} else {
			if (defined $fileRuleAtt{'maxlength'}) {
				return 0 unless length $fileName <= $fileRuleAtt{'maxlength'};
			}
			if (defined $fileRuleAtt{'minlength'}) {
				return 0 unless length $fileName >= $fileRuleAtt{'minlength'};
			}
		}

		substr($fileRule, 0, 1, ''); # Efface le caract�re '~' au d�but de l'expression

		# Traitement des r�f�rences de charsets
		while ($fileRule =~ /.*%([-_a-zA-Z0-9]+)%.*/) {
			my $charset = $1;
			$fileRule =~ s/(.*)(%[-_a-zA-Z0-9]+%)(.*)/$1$charsets{$charset}$3/;
		}

		# Teste si le nom de fichier de la requ�te correspond � celui de la r�gle
		return 0 unless $fileName =~ /$fileRule/;

		return 1;

	} elsif ($fileRule =~ /(.*)%([^%]+)%(.*)/) {

		### Expression simple utilisant un charset

		# Teste la longueur totale du nom de fichier
		if (defined $fileRuleAtt{'length'}) {
			return 0 unless length $fileName == $fileRuleAtt{'length'};
		} else {
			if (defined $fileRuleAtt{'maxlength'}) {
				return 0 unless length $fileName <= $fileRuleAtt{'maxlength'};
			}
			if (defined $fileRuleAtt{'minlength'}) {
				return 0 unless length $fileName >= $fileRuleAtt{'minlength'};
			}
		}

		# D�coupe du fileRule en 3 slices (exact, regexp, exact)
		my @ruleSlices = ($1, $2, $3);

		# Remplacement du charset par sa valeur en expression r�guli�re
		if (exists $charsets{$ruleSlices[1]}) {
			$ruleSlices[1] = $charsets{$ruleSlices[1]};
		}

		# D�coupe du fileName en 3 slices de longueur correspondante aux slices du fileRule
		my @fileNameSlices;
		$fileNameSlices[0] = substr($fileName, 0, length $ruleSlices[0], '');
		$fileNameSlices[2] = substr($fileName, (length $fileName)-(length $ruleSlices[2]), length $ruleSlices[2], '');
		$fileNameSlices[1] = $fileName;

		# Application des r�gles pour les 3 slices
		return 0 unless $fileNameSlices[0] eq $ruleSlices[0];
		return 0 unless $fileNameSlices[1] =~ /^$ruleSlices[1]$/;
		return 0 unless $fileNameSlices[2] eq $ruleSlices[2];

		return 1;

	} else {

		### Expression simple sans charset ("exact match")

		return 0 unless $fileName eq $fileRule;
		return 1;

	}
}

# Teste si une URL de la requ�te (1er param�tre) satisfait une r�gle <url> (2�me param�tre)
#
# Param�tres :
#
#  1) $url : URL � �valuer (en r�alit� URI, de la forme "/path/to/file?param1=value1")
#  2) %urlRule : r�gle <url> avec laquelle �valuer l'URL
#
sub matchUrl {

	my ($url, %urlRule) = @_;
	my $log = Apache->server->log;
	my $temp = (keys %urlRule)[0];
	return matchFile ($url, %urlRule);

}

# Teste si une requ�te de script satisfait une r�gle <script>
#
# 2 syntaxes possibles :
#
#  1. matchScript ($scriptName, \%scriptRule)
#  2. matchScript ($scriptName, $get_params, $post_params, \%scriptRule)
#
# La syntaxe avec 2 param�tres est utilis�e pour �valuer des r�gles <script> dans
# le contexte <deny>, dans ce cas matchScript fonctionne comme matchFile, c'est �
# dire que seul le nom de fichier de la requ�te est compar� � celui de la r�gle <script>.
#
# La syntaxe avec 4 param�tres est utilis�e pour �valuer des r�gles <script> dans
# le contexte <allow>. Pour que la r�gle soit satisfaite, le nom de fichier de
# la requ�te et de la r�gle <script> doivent correspondre, de m�me que les noms,
# valeurs et longueurs de chaque param�tre du script. Attention: certains param�tres
# de la r�gle peuvent �tre d�finis mandatoires alors que d'autres sont optionnels.
#
sub matchScript {

	my ($scriptName, %scriptRule, $get_params, $post_params);
	my $log = Apache->server->log;

	if (scalar @_ == 2) {
		# Syntaxe � 2 param�tres
		# debug ('matchScript: 2 parametres', \$r->server->log);
		$scriptName = shift @_;
		%scriptRule = %{ shift @_ };

		my $ruleName = (keys %scriptRule)[0];
		if (matchFile ($scriptName, %scriptRule)) {
			# debug ("matchScript: $scriptName == $ruleName", \$log);
		} else {
			# debug ("matchScript: $scriptName != $ruleName", \$log);
		}

		# Utilise matchFile pour comparer le nom du script avec celui de la r�gle <script>
		return matchFile ($scriptName, %scriptRule);

	} elsif (scalar @_ == 4) {
		# Syntaxe � 4 param�tres
		# debug ('matchScript: 4 parametres', \$log);

		$scriptName = shift @_;
		$get_params = shift @_;
		$post_params = shift @_;
		%scriptRule = %{ shift @_ };
		my $ruleName = (keys %scriptRule)[0];

		# Utilise matchFile pour comparer le nom du script avec celui de la r�gle <script>
		return 0 unless matchFile ($scriptName, %scriptRule);

		# Pour chaque param�tre GET de la requ�te, boucler
		my $forbidden = 0;
		$get_params->do(sub{
			my ($paramName, $paramValue) = @_;
			my $param_ok = 0;
			# Pour chaque param�tre <param> de la r�gle <script>, boucler
			for (keys %{ $scriptRule{$ruleName}{'params'}}) {
				my %rule = ($_ => $scriptRule{$ruleName}{'params'}{$_});
				if (matchParam($paramName, $paramValue,'get', \%rule)) {
					$param_ok = 1;
					last;
				}
			}
			
			# Le script ne satisfait pas la r�gle si au moins un param�tre GET
			# de la requ�te n'est pas d�clar� comme <param> dans la r�gle <script>
			if (!$param_ok) {
				$forbidden = 1;
				return 0;
			}
			1;
		});
		# Si un param�tre GET n'a pas de r�gle <param> correspondante, la r�gle script n'est pas satisfaite
		return 0 if $forbidden;

		# Pour chaque param�tre POST de la requ�te, boucler
		$forbidden = 0;
		$post_params->do(sub{
			my ($paramName, $paramValue) = @_;
			my $param_ok = 0;
			# Pour chaque param�tre <param> de la r�gle <script>, boucler
			for (keys %{ $scriptRule{$ruleName}{'params'}}) {
				my %rule = ($_ => $scriptRule{$ruleName}{'params'}{$_});
				if (matchParam($paramName, $paramValue,'post', \%rule)) {
					$param_ok = 1;
					last;
				}
			}
			
			# Le script ne satisfait pas la r�gle si au moins un param�tre GET
			# de la requ�te n'est pas d�clar� comme <param> dans la r�gle <script>
			if (!$param_ok) {
				$forbidden = 1;
				return 0;
			}
			1;
		});
		# Si un param�tre POST n'a pas de r�gle <param> correspondante, la r�gle script n'est pas satisfaite
		return 0 if $forbidden;

		# V�rifier que tous les param�tres non-optionnels de la r�gle
		# soient bien pr�sents dans la requ�te
		# Pour chaque param�tre <param> de la r�gle <script>, boucler
		for my $paramRuleName (keys %{ $scriptRule{$ruleName}{'params'} }) {
			# Ne teste que les param�tres mandatoires
			if ($scriptRule{$ruleName}{'params'}{$paramRuleName}{'optional'} eq 'false') {
				my $param_ok = 0;
				my %rule = ($paramRuleName => $scriptRule{$ruleName}{'params'}{$paramRuleName});

				if ($scriptRule{$ruleName}{'params'}{$paramRuleName}{'method'} =~ /both/i) {
					# Recherche un param�tre correspondant � la r�gle parmi ceux transmis par GET
					$get_params->do(sub{
						my ($paramName, $paramValue) = @_;
							if (matchParam($paramName, $paramValue, 'get', \%rule)) {
								$param_ok = 1;
								return 0;
							}
						1;
					});
					# Recherche un param�tre correspondant � la r�gle parmi ceux transmis par POST
					$post_params->do(sub{
						my ($paramName, $paramValue) = @_;
						return 0 if $param_ok;
							if (matchParam($paramName, $paramValue, 'post', \%rule)) {
								$param_ok = 1;
								return 0;
							}
						1;
					});
				} elsif ($scriptRule{$ruleName}{'params'}{$paramRuleName}{'method'} =~ /get/i) {
					# Recherche un param�tre correspondant � la r�gle parmi ceux transmis par GET
					$get_params->do(sub{
						my ($paramName, $paramValue) = @_;
							if (matchParam($paramName, $paramValue, 'get', \%rule)) {
								$param_ok = 1;
								return 0;
							}
						1;
					});					
				} elsif ($scriptRule{$ruleName}{'params'}{$paramRuleName}{'method'} =~ /post/i) {
					# Recherche un param�tre correspondant � la r�gle parmi ceux transmis par POST
					$post_params->do(sub{
						my ($paramName, $paramValue) = @_;
						return 0 if $param_ok;
							if (matchParam($paramName, $paramValue, 'post', \%rule)) {
								$param_ok = 1;
								return 0;
							}
						1;
					});
				}

				# Le script ne satisfait pas � la r�gle si au moins un des param�tres mandatoires
				# (optional = false) ne se trouve pas dans la requ�te
				return 0 unless $param_ok;

			}
		}

		return 1; # Chaque param�tre du script satisfait une r�gle <param> --> requ�te valide

	} else {
		debug ('matchScript: bad parameter number', \$log);
		return 0;
	}
}

# �value si un param�tre de script correspond � une r�gle <param> sur la base de son nom,
# sa valeur, sa m�thode POST ou GET et sa longueur
#
# Param�tres :
#   1. $paramName : le nom du param�tre de la requ�te
#   2. $paramValue : la valeur du param�tre de la requ�te
#   3. $paramMethod : la m�thode du param�tre de la requ�te (post ou get)
#   4. \%paramRule : un �l�ment du hash %{'param'} associ� � une r�gle <script>
#
sub matchParam {
	my $paramName = shift @_;
	my $paramValue = shift @_;
	my $paramMethod = shift @_;
	my %pr = %{ shift @_ };
	my $paramRule = (keys %pr)[0];
	my $log = Apache->server->log;

	# debug ("matchParam: paramName=$paramName, paramRule=$paramRule", \$log);

	# Teste si le nom du param�tre de la requ�te correspond � celui de la r�gle <param>
	return 0 unless $paramName eq $paramRule;

	# Teste si la m�thode GET/POST du param�tre de la requ�te correspond � celui de la r�gle <param>
	my %paramRuleAtt = %{ $pr{$paramRule} };

	if (lc $paramRuleAtt{'method'} eq 'get') {
		return 0 unless lc $paramMethod eq 'get';
	} elsif (lc $paramRuleAtt{'method'} eq 'post') {
		return 0 unless lc $paramMethod eq 'post';
	}

	# Teste si l'attribut valeur de la r�gle emploie la syntaxe regexp
	my $paramRuleValue = $paramRuleAtt{'value'};
	if (substr($paramRuleValue, 0, 1) eq '~') {
	
		### Expression r�guli�re

		# Teste la longueur de la valeur du param�tre
		if (defined $paramRuleAtt{'length'}) {
			return 0 unless length $paramValue == $paramRuleAtt{'length'}
		} else {
			if (defined $paramRuleAtt{'maxlength'}) {
				return 0 unless length $paramValue <= $paramRuleAtt{'maxlength'};
			}
			if (defined $paramRuleAtt{'minlength'}) {
				return 0 unless length $paramValue >= $paramRuleAtt{'minlength'};
			}
		}

		substr($paramRuleValue, 0, 1, ''); # Efface le caract�re '~' au d�but de l'expression

		# Traitement des r�f�rences de charsets
		while ($paramRuleValue =~ /.*%([-_a-zA-Z0-9]+)%.*/) {
			my $charset = $1;
			$paramRuleValue =~ s/(.*)(%[-_a-zA-Z0-9]+%)(.*)/$1$charsets{$charset}$3/;
		}

		# Teste si la valeur du param�tre de la requ�te correspond � celle de la r�gle <param>
		return 0 unless $paramValue =~ /$paramRuleValue/;

		return 1; # Le param�tre effectif correspond � la r�gle <param>

	} elsif ($paramRuleValue =~ /(.*)%([^%]+)%(.*)/) {

		### Expression simple utilisant un charset

		# Teste la longueur de la valeur du param�tre
		if (defined $paramRuleAtt{'length'}) {
			return 0 unless length $paramValue == $paramRuleAtt{'length'}
		} else {
			if (defined $paramRuleAtt{'maxlength'}) {
				return 0 unless length $paramValue <= $paramRuleAtt{'maxlength'};
			}
			if (defined $paramRuleAtt{'minlength'}) {
				return 0 unless length $paramValue >= $paramRuleAtt{'minlength'};
			}
		}

		# D�coupe du paramRuleValue en 3 slices (exact, regexp, exact)
		my @ruleSlices = ($1, $2, $3);

		# Remplacement du charset par sa valeur en expression r�guli�re
		if (exists $charsets{$ruleSlices[1]}) {
			$ruleSlices[1] = $charsets{$ruleSlices[1]};
		}

		# D�coupe du paramValue en 3 slices de longueur correspondante aux slices du paramRuleValue
		my @paramValueSlices;
		$paramValueSlices[0] = substr($paramValue, 0, length $ruleSlices[0], '');
		$paramValueSlices[2] = substr($paramValue, (length $paramValue)-(length $ruleSlices[2]), length $ruleSlices[2], '');
		$paramValueSlices[1] = $paramValue;

		# Application des r�gles pour les 3 slices
		return 0 unless $paramValueSlices[0] eq $ruleSlices[0];
		return 0 unless $paramValueSlices[1] =~ /^$ruleSlices[1]$/;
		return 0 unless $paramValueSlices[2] eq $ruleSlices[2];

		return 1; # Le param�tre effectif correspond � la r�gle <param>
	
	} else {
	
		### Expression simple sans charset ("exact match")
	
		return 0 unless $paramValue eq $paramRuleValue;
		return 1; # Le param�tre effectif correspond � la r�gle <param>	
	}
	
}

# Filtre les ent�tes de la r�ponse du serveur avant de les envoyer au client
#
# Param�tres : 
#   1) r�f�rence sur l'objet HTTP::Response renvoy� par LWP::UserAgent
#   2) r�f�rence sur l'objet Apache::Request dans lequel copier les ent�tes valides
#
# Valeurs de retour :
#
#   1 : r�ponse valide (toutes les ent�tes sont soit accept�es, soit filtr�es)
#   0 : r�ponse interdite (au moins une ent�te interdite par une r�gle deny ou le comportement par d�faut)
#  -1 : erreur de configuration
#
sub headersOutFilter {

	my $response = ${ shift @_ };
	my $r = ${ shift @_ };
	my $forbidden = 0;
	my $serverError = 0;
	$r->content_type($response->header('Content-type'));
	$r->status($response->code());
	$r->status_line($response->code().' '.$response->message());

	### Scan des ent�tes de la r�ponse
	$response->scan(sub {
		my ($headerName, $headerValue) = @_;
		debug ("Response header : $headerName = $headerValue", \$r->server->log);
		if ($headerName =~ /Content-type/i) {
			return 1;
		} elsif ($headerName =~ /Location/i && length $headerValue) {
			
			### Traitement des redirections (ent�tes Location)

			my $redirectUrl;
			if ($headerValue =~ m|^http://|i) {
				# Redirection avec URL absolue
				$redirectUrl = $headerValue;
			} elsif ($headerValue =~ m|^/|) {
				# Redirection avec adresse source relative � la racine du serveur cible
				my $targetServer = $response->base->host;
				$redirectUrl = 'http://'.$targetServer.$headerValue;
			}

			if ($redirectUrl) {
				my $matchingPrefix = '';
				# Recherche la r�gle reverse_mapping qui correspond le mieux � l'ent�te Location de la r�ponse
				my $log = Apache->server->log;
				for my $srcUrl (keys %reverse_mapping) {
					debug ("srcUrl=$srcUrl", \$log);
					if ($redirectUrl =~ m|^$srcUrl|i && length $srcUrl > length $matchingPrefix) {
						$matchingPrefix = $srcUrl;
					}
				}
				if (length $matchingPrefix) {
					$redirectUrl =~ s|^$matchingPrefix|$reverse_mapping{$matchingPrefix}|i;
					$r->headers_out->set('Location' => $redirectUrl);
					debug ("Location: $headerValue translated to Location: $redirectUrl", \$r->server->log);
				}		
			} else {
				$r->headers_out->set('Location' => $headerValue);
				debug ("Location: $headerValue header not translated", $r->server->log);
			}
			
		} else {
			
			### Filtrage des autres ent�tes de la r�ponse
			
			if ($config{'headers_out'}{'default'} eq 'allow') {
				# Default-policy = allow -> recherche une r�gle deny ou filter correspondant au header_out
				if (exists $config{'headers_out'}{'deny'}{lc $headerName}) {
					info ("header_out $headerName forbidden by rule", \$r->server->log);
					$r->headers_out->unset($headerName);
					$forbidden = 1;
					return 0;
				} elsif (exists $config{'headers_out'}{'filter'}{lc $headerName}) {
					$r->headers_out->unset($headerName);
					debug ("header_out $headerName has been filtered by rule", \$r->server->log);
				} else {
					# Comportement par d�faut allow --> copie l'ent�te dans la r�ponse au client
					$r->headers_out->add($headerName => $headerValue);
				}

			} elsif ($config{'headers_out'}{'default'} eq 'deny') {
				# Default-policy = deny --> recherche une r�gle filter ou allow correspondant au header_out
				if (exists $config{'headers_out'}{'filter'}{lc $headerName}) {
					debug ("header_out $headerName has been filtered by rule", \$r->server->log);
					$r->headers_out->unset($headerName);
				} elsif (exists $config{'headers_out'}{'allow'}{lc $headerName}) {
					my %headerRule = %{ $config{'headers_out'}{'allow'}{lc $headerName} };
					if (matchHeader($headerValue, %headerRule)) {
						$r->headers_out->add($headerName => $headerValue);
					} else {
						info ("header_out $headerName forbidden by rule : no matching allow rule", \$r->server->log);
						$r->headers_out->unset($headerName);
						$forbidden = 1;
						return 0;
					}
				} else {
					# Comportement par d�faut deny --> requ�te refus�e
					info ("header_out $headerName forbidden by default rule : no matching allow rule", \$r->server->log);
					$r->headers_out->unset($headerName);
					$forbidden = 1;
					return 0;
				}

			} elsif ($config{'headers_out'}{'default'} eq 'filter') {
				# Default-policy = filter --> recherche une r�gle deny ou allow correspondant au header_out
				if (exists $config{'headers_out'}{'deny'}{lc $headerName}) {
					info ("header_out $headerName forbidden by rule", \$r->server->log);
					$r->headers_out->unset($headerName);
					$forbidden = 1;
					return 0;
				} elsif (exists $config{'headers_out'}{'allow'}{lc $headerName}) {
					my %headerRule = %{ $config{'headers_out'}{'allow'}{lc $headerName} };
					if (matchHeader($headerValue, %headerRule)) {
						$r->headers_out->add($headerName => $headerValue);
					} else {
						debug ("header_out $headerName has been filtered by default rule : no matching allow rule", \$r->server->log);
						$r->headers_out->unset($headerName);
					}
				} else {
					# Comportement par d�faut filter --> le header_out n'est pas copi� dans la r�ponse au client
					debug ("header_out $headerName has been filtered by default rule : no matching allow rule", \$r->server->log);
					$r->headers_out->unset($headerName);
				}
				
			} else {
				error ("Bad default policy for \"headers_out\", must be deny, allow or filter", \$r->server->log);
				$serverError = 1;
				return 0;
			}
			
			### Fin de filtrage des autres ent�tes de la r�ponse
		}
		1;
	}); ### Fin de scan des ent�tes de la r�ponse
	return 0 if $forbidden;
	return -1 if $serverError;
	return 1;
}

# Ajoute les param�tres � la fin de l'URL selon la syntaxe x-www-form-urlencoded
#
# Param�tres :
#
#  1) $uri = URI/URL compl�te sans param�tre(s)
#  2) $get_params = instance de Apache::Table contenant la liste des param�tres
#
# Retourne : une cha�ne de caract�re repr�sentant l'URL compl�te avec les param�tres
#
sub addParamString {

	my $uri = shift @_;
	my $get_params = shift @_;
	my $firstTime = 1;
	$get_params->do(sub{
		my ($paramName, $paramValue) = @_;
		if ($firstTime) {
			$uri .= '?'.$paramName.'='.$paramValue;
			$firstTime = 0;
		} else {
			$uri .= '&'.$paramName.'='.$paramValue;
		}
		1;
	});
	return $uri;
}

# �value si une requ�te doit �tre accept�e ou rejet�e sur la base du nom de fichier,
# du default-policy pour le r�pertoire courant et de l'ensemble des r�gles <file>.
#
# Param�tres :
#   1.  $fileName : le nom de fichier de la requ�te
#   2.  $pwd : le contexte (r�pertoire courant de l'application)
#
# Valeur de retour :
#   "1" --> requ�te autoris�e
#   "0" --> requ�te refus�e
#
sub fileAllowed() {
	my ($fileName, $pwd) = @_;
	my $policy = getDefault($pwd);
	my %denyFileRules = getFiles ($pwd, 'deny');
	my %allowFileRules = getFiles ($pwd, 'allow');
	my $log = Apache->server->log;
	my $matchDeny = 0;
	my $matchAllow = 0;

	# Teste si le r�pertoire du fichier est valide (d�clar� par <directory>)
	return 0 unless exists $default{$pwd};

	# Corrige le probl�me du trailing slash manquant en ajoutant un slash si le
	# nom de fichier correspond � celui d'un r�pertoire valide
	if ($fileName ne '' && exists $default{"$pwd$fileName/"}) {
		$pwd = "$pwd$fileName/";
		$fileName = '';
	}

	# Si c'est l'index de r�pertoire qui est appel�, teste s'il est autoris� dans le r�pertoire courant
	if ($fileName eq '') {
		return 0 unless getAllowIndex($pwd) eq 'true';
		return 1;
	}

	if ($policy eq 'allow') {

		# Default-policy = allow --> les blocs Deny sont evalu�s en premier
		# Toute requ�te qui ne satisfait aucune r�gle Deny OU
		# qui satisfait une r�gle Allow est autoris�e
		for my $ruleName (keys %denyFileRules) {
			my %rule = ($ruleName => $denyFileRules{$ruleName});
			if (matchFile ($fileName, %rule)) {
				$matchDeny = 1;
				last;
			}
		}

		if ($matchDeny) {
			# Recherche un r�gle Allow qui puisse r�cup�rer le Deny (priorit� du Allow sur le Deny)
			for my $ruleName (keys %allowFileRules) {
				my %rule = ($ruleName => $allowFileRules{$ruleName});
				if (matchFile ($fileName, %rule)) {
					$matchAllow = 1;
					return 1; # Au moins une r�gle Allow satisfaite --> requ�te autoris�e
				}
			}
			
			return 0; # Au moins une r�gle Deny et aucune r�gle Allow --> requ�te refus�e
			
		} else {

			return 1; # Aucune r�gle Deny --> requ�te autoris�e

		}

	} else { # $policy eq 'deny'

		# Default-policy = deny --> les blocs Allow sont evalu�s en premier
		# Toute requ�te qui ne satisfait aucune r�gle Allow OU
		# qui satisfait une r�gle Deny sera refus�e
		for my $ruleName (keys %allowFileRules) {
			my %rule = ($ruleName => $allowFileRules{$ruleName});
			if (matchFile ($fileName, %rule)) {
				$matchAllow = 1;
				last;
			}
		}
		
		if ($matchAllow) {
		
			# Recherche une r�gle Deny qui soit satisfaite
			for my $ruleName (keys %denyFileRules) {
				my %rule = ($ruleName => $denyFileRules{$ruleName});
				if (matchFile ($fileName, %rule)) {
					$matchDeny = 1;
					return 0; # Au moins une r�gle Deny satisfaite --> requ�te refus�e
				}
			}

			return 1; # Au moins une r�gle Allow satisfaite et aucune r�gle Deny --> requ�te accept�e

		} else {
			return 0; # Aucune r�gle Allow satisfaite --> requ�te refus�e
		}

	}

}

# �value si une requ�te doit �tre accept�e ou rejet�e sur la base de l'URL,
# du default-policy pour le r�pertoire courant et de l'ensemble des r�gles <url>.
#
# Param�tres :
#   1.  $url : URL de la requ�te
#
# Valeur de retour :
#   "1" --> requ�te autoris�e
#   "-1" --> requ�te refus�e
#	"0" --> verdict neutre
#
sub urlAllowed() {
	my $requestUrl = shift @_;
	my $log = Apache->server->log;
	my %denyUrlRules = getUrls ('deny');
	my %allowUrlRules = getUrls ('allow');
	my $matchDeny = 0;
	my $matchAllow = 0;

	# Recherche une r�gle "deny" qui soit satisfaite
	for my $ruleName (keys %denyUrlRules) {
		my %rule = ($ruleName => $denyUrlRules{$ruleName});
		if (matchUrl ($requestUrl, %rule)) {
			$matchDeny = 1;
			last;
		}
	}

	# Recherche une r�gle "allow" qui soit satisfaite
	for my $ruleName (keys %allowUrlRules) {
		my %rule = ($ruleName => $allowUrlRules{$ruleName});
		if (matchUrl ($requestUrl, %rule)) {
			$matchAllow = 1;
			last;
		}
	}

	# D�termine le verdict
	if ($matchDeny && !$matchAllow) {

		return -1; # Requ�te refus�e

	} elsif ($matchAllow && !$matchDeny) {

		return 1; # Requ�te accept�e

	} elsif ($matchAllow && $matchDeny) {
	
		# Cas de litige --> consulte le default-policy pour l'�l�ment <webapp>
		my $policy = &getDefault('/');
		if ($policy eq 'allow') {
			return 1;
		} elsif ($policy eq 'deny') {
			return -1;
		} else {
			return 0;
		}
	
	} else {
	
		# Aucune r�gle allow ou deny satisfaite --> verdict neutre
		return 0;
	
	}

}

# �value si une requ�te comportant des param�tres (POST ou GET) doit �tre accept�e ou rejet�e
# sur la base du nom de fichier, des param�tres transmis,  du default-policy pour le r�pertoire
# courant et de l'ensemble des r�gles <script>.
#
# Param�tres :
#   1.  %scriptRequest : hash contenant le nom du script et les param�tres transmis (GET et POST)
#   2.  $pwd : le contexte (r�pertoire courant de l'application)
#
# Valeur de retour :
#   "1" --> requ�te autoris�e
#   "0" --> requ�te refus�e
#
sub scriptAllowed() {

	my $log = Apache->server->log;
	my $nbParams = scalar @_;
	my %scriptRequest = %{ shift @_ };
	my $pwd = shift @_;
	my $scriptName = (keys %scriptRequest)[0];
	my $get_params = $scriptRequest{$scriptName}{'get'};
	my $post_params = $scriptRequest{$scriptName}{'post'};
	my $policy = getDefault($pwd);
	my %denyScriptRules = getScripts ($pwd, 'deny');
	my %allowScriptRules = getScripts ($pwd, 'allow');
	my $matchDeny = 0;
	my $matchAllow = 0;

	# Teste si le r�pertoire du script est valide (d�clar� par <directory>)
	return 0 unless exists $default{$pwd};

	if ($policy eq 'allow') {

		# Default-policy = allow --> les blocs Deny sont evalu�s en premier
		# Toute requ�te qui ne satisfait aucune r�gle Deny OU
		# qui satisfait une r�gle Allow est autoris�e
		for my $ruleName (keys %denyScriptRules) {
			my %rule = ($ruleName => $denyScriptRules{$ruleName});
			if (matchScript ($scriptName, \%rule)) {
				$matchDeny = 1;
				last;
			}
		}

		if ($matchDeny) {
			# Recherche un r�gle Allow qui puisse r�cup�rer le Deny (priorit� du Allow sur le Deny)
			for my $ruleName (keys %allowScriptRules) {
				my %rule = ($ruleName => $allowScriptRules{$ruleName});
				if (matchScript ($scriptName, $get_params, $post_params, \%rule)) {
					$matchAllow = 1;
					return 1; # Au moins une r�gle Allow satisfaite --> requ�te autoris�e
				}
			}
			
			return 0; # Au moins une r�gle Deny satisfaite et aucune r�gle Allow --> requ�te refus�e
			
		} else {

			return 1; # Aucune r�gle Deny --> requ�te autoris�e

		}

	} else {

		# Default-policy = deny --> les blocs Allow sont evalu�s en premier
		# Toute requ�te qui ne satisfait aucune r�gle Allow OU
		# qui satisfait une r�gle Deny sera refus�e
		for my $ruleName (keys %allowScriptRules) {
			my %rule = ($ruleName => $allowScriptRules{$ruleName});
			if (matchScript ($scriptName, $get_params, $post_params, \%rule)) {
				$matchAllow = 1;
				last;
			}
		}

		if ($matchAllow) {

			# Recherche une r�gle Deny qui soit satisfaite
			for my $ruleName (keys %denyScriptRules) {
				my %rule = ($ruleName => $denyScriptRules{$ruleName});
				if (matchScript ($scriptName, \%rule)) {
					$matchDeny = 1;
					return 0; # Au moins une r�gle Deny satisfaite --> requ�te refus�e
				}
			}

			return 1; # Au moins une r�gle Allow satisfaite et aucune r�gle Deny --> requ�te accept�e

		} else {

			return 0; # Aucune r�gle Allow satisfaite --> requ�te refus�e

		}

	}

	return 1; # Requ�te autoris�e
}

#  -+-                                   -+-
#  -+- GESTION DES ERREURS / HISTORIQUE  -+-
#  -+-                                   -+-

# Appel� lorsqu'une erreur fatale survient
sub error {
	if (defined $config{'loglevel'}) {
		return 0 unless $config{'loglevel'} =~ m/(error|warning|info|debug)/;
	}
	my $error_msg = shift @_;
	my $log = ${ shift @_ };
	if (defined $config{'logfile'}) {
		if (!open LOGFILE, ">>$config{'logfile'}") {
			$log->error("Can't open ProxyFilter logfile for append: $!");
			return SERVER_ERROR;	
		}
		print LOGFILE "[error] : $error_msg\n";
		close LOGFILE;
	} else {
		$log->error($error_msg);
	}
}

# Appel� pour �crire un message de debug
sub debug {
	if (defined $config{'loglevel'}) {
		return 0 unless $config{'loglevel'} eq 'debug';
	}
	my $debug_msg = shift @_;
	my $log = ${ shift @_ };
	if (defined $config{'logfile'}) {
		if (!open LOGFILE, ">>$config{'logfile'}") {
			$log->error("Can't open ProxyFilter logfile for append: $!");
			return SERVER_ERROR;
		}
		print LOGFILE "[debug] : $debug_msg\n";
		close LOGFILE;
	} else {
		$log->debug($debug_msg);
	}
}

# Appel� pour �crire un message d'avertissement
sub warning {
	if (defined $config{'loglevel'}) {
		return 0 unless $config{'loglevel'} =~ m/(warning|info|debug)/;
	}
	my $warn_msg = shift @_;
	my $log = ${ shift @_ };
	if (defined $config{'logfile'}) {
		if (!open LOGFILE, ">>$config{'logfile'}") {
			$log->error("Can't open ProxyFilter logfile for append: $!");
			return SERVER_ERROR;	
		}
		print LOGFILE "[warn] : $warn_msg\n";
		close LOGFILE;
	} else {
		$log->warn($warn_msg);
	}
}

# Appel� pour �crire un message d'info
sub info {
	if (defined $config{'loglevel'}) {
		return 0 unless $config{'loglevel'} =~ m/(info|debug)/;
	}
	my $info_msg = shift @_;
	my $log = ${ shift @_ };
	if (defined $config{'logfile'}) {
		if (!open LOGFILE, ">>$config{'logfile'}") {
			$log->error("Can't open ProxyFilter logfile for append: $!");
			return SERVER_ERROR;	
		}
		print LOGFILE "[info] : $info_msg\n";
		close LOGFILE;
	} else {
		$log->info($info_msg);
	}
}

#  -+-                    -+-
#  -+- ROUTINES DE DEBUG  -+-
#  -+-                    -+-

# Affiche le contenu de la structure de donn�es interne de configuration
sub showConfig {
	if (defined $config{'charsetsfile'}) {
		print "-> charsetsfile : $config{'charsetsfile'}\n";
	} else {
		print "[error] : charsetsfile not defined\n";
	}
	if (defined $config{'webappfile'}) {
		print "-> webappfile : $config{'webappfile'}\n";
	} else {
		print "[error] : webappfile not defined\n";
	}
	if (defined $config{'logfile'}) {
		print "-> logfile : $config{'logfile'}\n";
	} else {
		print "[error] : logfile not defined\n";
	}
	if (defined $config{'mappingsfile'}) {
		print "-> mappingsfile : $config{'mappingsfile'}\n";
	} else {
		print "[error] : mappingsfile not defined\n";
	}

	print "\n-> headers_in: (default: $config{'headers_in'}{'default'})\n";
	for my $policy (qw/allow deny filter/) {
		print "  $policy:\n";
		for (keys %{ $config{'headers_in'}{$policy}}) {
			print "    $_ = $config{'headers_in'}{$policy}{$_}{'value'}\n";
		}
	}

	print "\n-> headers_out: (default: $config{'headers_out'}{'default'})\n";
	for my $policy (qw/allow deny filter/) {
		print "  $policy:\n";
		for (keys %{ $config{'headers_out'}{$policy}}) {
			print "    $_ = $config{'headers_out'}{$policy}{$_}{'value'}\n";
		}
	}

	print "-> default-policy:\n";
	while (my ($key, $value) = each %default) {
		print "     $key => $value\n";
	}

	print "\n-> allowindex:\n";
	while (my ($key, $value) = each %allowindex) {
		print "     $key => $value\n";
	}

	print "\n-> file:\n";
	foreach my $policy (keys %file) {
		print "     $policy:\n";
		foreach my $path (keys %{ $file{$policy} }) {
			foreach my $fileName (keys %{ $file{$policy}{$path} }) {
				print "       $path$fileName\n";
				print "          inherit: ".$file{$policy}{$path}{$fileName}{'inherit'}."\n";
				print "          length: ".$file{$policy}{$path}{$fileName}{'length'}."\n";
				print "          minlength: ".$file{$policy}{$path}{$fileName}{'minlength'}."\n";
				print "          maxlength: ".$file{$policy}{$path}{$fileName}{'maxlength'}."\n";
			}
		}
	}

	print "\n-> url:\n";
	foreach my $policy (keys %url) {
		print "     $policy:\n";
		foreach my $path (keys %{ $url{$policy} }) {
			print "       $path :\n";
			foreach my $urlExpression (keys %{ $url{$policy}{$path} }) {
				print "          $urlExpression\n";
				print "             inherit: ".$url{$policy}{$path}{$urlExpression}{'inherit'}."\n";
				print "             length: ".$url{$policy}{$path}{$urlExpression}{'length'}."\n";
				print "             minlength: ".$url{$policy}{$path}{$urlExpression}{'minlength'}."\n";
				print "             maxlength: ".$url{$policy}{$path}{$urlExpression}{'maxlength'}."\n";
			}
		}
	}

	print "\n-> script:\n";
	foreach my $policy (keys %script) {
		print "     $policy:\n";
		foreach my $path (keys %{ $script{$policy} }) {
			foreach my $scriptName (keys %{ $script{$policy}{$path} }) {
				print "       $path$scriptName\n";
				print "          inherit: ".$script{$policy}{$path}{$scriptName}{'inherit'}."\n";
				print "          length: ".$file{$policy}{$path}{$scriptName}{'length'}."\n";
				print "          minlength: ".$file{$policy}{$path}{$scriptName}{'minlength'}."\n";
				print "          maxlength: ".$file{$policy}{$path}{$scriptName}{'maxlength'}."\n";
				print "          params:\n";
				foreach my $param (keys %{ $script{$policy}{$path}{$scriptName}{'params'} }) {
					my $value = $script{$policy}{$path}{$scriptName}{'params'}{$param}{'value'};
					print "             $param=$value\n";
				}
			}
		}
	}

	print "\n-> mappings:\n";
	print "  prefix\n";
	for (keys %prefix_mapping) {
		print "    $_ => $prefix_mapping{$_}\n";
	}
	
	print "\n  reverse\n";
	for (keys %reverse_mapping) {
		print "    $_ => $reverse_mapping{$_}\n";
	}

	print "\n  exact\n";
	for (keys %exact_mapping) {
		print "    $_ => $exact_mapping{$_}\n";
	}

}

1;
__END__